/*This source code copyrighted by Lazy Foo' Productions 2004-2026
and may not be redistributed without written permission.*/

/* Headers */
//Using SDL, SDL_image, and STL string
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_image/SDL_image.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <string>


/* Constants */
//Screen dimension constants
constexpr int kScreenWidth{ 640 };
constexpr int kScreenHeight{ 480 };
constexpr int kScreenFps{ 60 };


/* Class Prototypes */
class LTexture
{
public:
    //Symbolic constant
    static constexpr float kOriginalSize = -1.f;

    //Initializes texture variables
    LTexture();

    //Cleans up texture variables
    ~LTexture();

    //Loads texture from disk
    bool loadFromFile( std::string path );

    #if defined(SDL_TTF_MAJOR_VERSION)
    //Creates texture from text
    bool loadFromRenderedText( std::string textureText, SDL_Color textColor );
    #endif

    //Cleans up texture
    void destroy();

    //Sets color modulation
    void setColor( Uint8 r, Uint8 g, Uint8 b);

    //Sets opacity
    void setAlpha( Uint8 alpha );

    //Sets blend mode
    void setBlending( SDL_BlendMode blendMode );

    //Draws texture
    void render( float x, float y, SDL_FRect* clip = nullptr, float width = kOriginalSize, float height = kOriginalSize, double degrees = 0.0, SDL_FPoint* center = nullptr, SDL_FlipMode flipMode = SDL_FLIP_NONE );

    //Gets texture attributes
    int getWidth();
    int getHeight();
    bool isLoaded();

private:
    //Contains texture data
    SDL_Texture* mTexture;

    //Texture dimensions
    int mWidth;
    int mHeight;
};

class LTimer
{
    public:
        //Initializes variables
        LTimer();

        //The various clock actions
        void start();
        void stop();
        void pause();
        void unpause();

        //Gets the timer's time
        Uint64 getTicksNS();

        //Checks the status of the timer
        bool isStarted();
        bool isPaused();

    private:
        //The clock time when the timer started
        Uint64 mStartTicks;

        //The ticks stored when the timer was paused
        Uint64 mPausedTicks;

        //The timer status
        bool mPaused;
        bool mStarted;
};

class Dot
{
    public:
        //The dimensions of the dot
        static constexpr int kDotWidth = 20;
        static constexpr int kDotHeight = 20;

        //Maximum axis velocity of the dot
        static constexpr int kDotVel = 10;

        //Initializes the variables
        Dot();

        //Set position
        void setPos( int x, int y );

        //Takes key presses and adjusts the dot's velocity
        void handleEvent( SDL_Event& e );

        //Moves the dot
        void move( int levelWidth, int levelHeight );

        //Shows the dot on the screen
        void render( SDL_Rect camera );

        //Collision box accessor
        SDL_Rect getCollider();

    private:
        //Position/size of the dot
        SDL_Rect mCollisionBox;

        //The velocity of the dot
        int mVelX, mVelY;
};

class House
{
public:
    //The house dimensions
    static constexpr int kHouseWidth = 40;
    static constexpr int kHouseHeight = 40;

    //Initializes variables
    House();

    //Sets the house's position/graphic
    void set( int x, int y, LTexture* houseTexture );

    //Renders house relative to the camera
    void render( SDL_Rect camera );

    //Gets the collision box
    SDL_Rect getCollider();

private:
    //The house graphic
    LTexture* mHouseTexture;

    //Position/size of the house
    SDL_Rect mCollisionBox;
};

class Door
{
public:
    //The door dimensions
    static constexpr int kDoorWidth = 20;
    static constexpr int kDoorHeight = 40;

    //Initializes variables
    Door();

    //Sets the door position
    void set( int x, int y );

    //Shows the door
    void render();

    //Gets the collision box
    SDL_Rect getCollider();

private:
    //Position/size of the door
    SDL_Rect mCollisionBox;
};

class GameState
{
public:
    //State transitions
    virtual bool enter() = 0;
    virtual bool exit() = 0;

    //Main loop functions
    virtual void handleEvent( SDL_Event& e ) = 0;
    virtual void update() = 0;
    virtual void render() = 0;

    //Make sure to call child destructors
    virtual ~GameState() = default;
};

class IntroState : public GameState
{
public:
    //Static accessor
    static IntroState* get();

    //Transitions
    bool enter() override;
    bool exit() override;

    //Main loop functions
    void handleEvent( SDL_Event& e ) override;
    void update() override;
    void render() override;

private:
    //Static instance
    static IntroState sIntroState;

    //Private constructor
    IntroState();

    //Intro background
    LTexture mBackgroundTexture;

    //Intro message
    LTexture mMessageTexture;
};


class TitleState : public GameState
{
public:
    //Static accessor
    static TitleState* get();

    //Transitions
    bool enter() override;
    bool exit() override;

    //Main loop functions
    void handleEvent( SDL_Event& e ) override;
    void update() override;
    void render() override;

private:
    //Static instance
    static TitleState sTitleState;

    //Private constructor
    TitleState();

    //Intro background
    LTexture mBackgroundTexture;

    //Intro message
    LTexture mMessageTexture;
};

class OverWorldState : public GameState
{
public:
    //Static accessor
    static OverWorldState* get();

    //Transitions
    bool enter() override;
    bool exit() override;

    //Main loop functions
    void handleEvent( SDL_Event& e ) override;
    void update() override;
    void render() override;

private:
    //Level dimensions
    static constexpr int kLevelWidth = kScreenWidth * 2;
    static constexpr int kLevelHeight = kScreenHeight * 2;

    //Static instance
    static OverWorldState sOverWorldState;

    //Private constructor
    OverWorldState();

    //Overworld textures
    LTexture mBackgroundTexture;
    LTexture mRedHouseTexture;
    LTexture mBlueHouseTexture;

    //Game objects
    House mRedHouse;
    House mBlueHouse;
};

class RedRoomState : public GameState
{
public:
    //Static accessor
    static RedRoomState* get();

    //Transitions
    bool enter() override;
    bool exit() override;

    //Main loop functions
    void handleEvent( SDL_Event& e ) override;
    void update() override;
    void render() override;

private:
    //Level dimensions
    static constexpr int kLevelWidth = kScreenWidth;
    static constexpr int kLevelHeight = kScreenHeight;

    //Static instance
    static RedRoomState sRedRoomState;

    //Private constructor
    RedRoomState();

    //Room textures
    LTexture mBackgroundTexture;

    //Game objects
    Door mExitDoor;
};

class BlueRoomState : public GameState
{
public:
    //Static accessor
    static BlueRoomState* get();

    //Transitions
    bool enter() override;
    bool exit() override;

    //Main loop functions
    void handleEvent( SDL_Event& e ) override;
    void update() override;
    void render() override;

private:
    //Level dimensions
    static constexpr int kLevelWidth = kScreenWidth;
    static constexpr int kLevelHeight = kScreenHeight;

    //Static instance
    static BlueRoomState sBlueRoomState;

    //Private constructor
    BlueRoomState();

    //Room textures
    LTexture mBackgroundTexture;

    //Game objects
    Door mExitDoor;
};

class ExitState : public GameState
{
public:
    //Static accessor
    static ExitState* get();

    //Transitions
    bool enter() override;
    bool exit() override;

    //Main loop functions
    void handleEvent( SDL_Event& e ) override;
    void update() override;
    void render() override;

private:
    //Static instance
    static ExitState sExitState;

    //Private constructor
    ExitState();
};


/* Function Prototypes */
//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();

//Check collision
bool checkCollision( SDL_Rect a, SDL_Rect b );

//State managers
void setNextState( GameState* nextState );
bool changeState();


/* Global Variables */
//The window we'll be rendering to
SDL_Window* gWindow{ nullptr };

//The renderer used to draw to the window
SDL_Renderer* gRenderer{ nullptr };

//Global assets
LTexture gDotTexture;
TTF_Font* gFont{ nullptr };

//Global game objects
Dot gDot;

//Game state object
GameState* gCurrentState{ nullptr };
GameState* gNextState{ nullptr };


/* Class Implementations */
//LTexture Implementation
LTexture::LTexture():
    //Initialize texture variables
    mTexture{ nullptr },
    mWidth{ 0 },
    mHeight{ 0 }
{

}

LTexture::~LTexture()
{
    //Clean up texture
    destroy();
}

bool LTexture::loadFromFile( std::string path )
{
    //Clean up texture if it already exists
    destroy();

    //Load surface
    if( SDL_Surface* loadedSurface = IMG_Load( path.c_str() ); loadedSurface == nullptr )
    {
        SDL_Log( "Unable to load image %s! SDL_image error: %s\n", path.c_str(), SDL_GetError() );
    }
    else
    {
        //Color key image
        if( SDL_SetSurfaceColorKey( loadedSurface, true, SDL_MapSurfaceRGB( loadedSurface, 0x00, 0xFF, 0xFF ) ) == false )
        {
            SDL_Log( "Unable to color key! SDL error: %s", SDL_GetError() );
        }
        else
        {
            //Create texture from surface
            if( mTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface ); mTexture == nullptr )
            {
                SDL_Log( "Unable to create texture from loaded pixels! SDL error: %s\n", SDL_GetError() );
            }
            else
            {
                //Get image dimensions
                mWidth = loadedSurface->w;
                mHeight = loadedSurface->h;
            }
        }
        
        //Clean up loaded surface
        SDL_DestroySurface( loadedSurface );
    }

    //Return success if texture loaded
    return mTexture != nullptr;
}

#if defined(SDL_TTF_MAJOR_VERSION)
bool LTexture::loadFromRenderedText( std::string textureText, SDL_Color textColor )
{
    //Clean up existing texture
    destroy();

    //Load text surface
    if( SDL_Surface* textSurface = TTF_RenderText_Blended( gFont, textureText.c_str(), 0, textColor ); textSurface == nullptr )
    {
        SDL_Log( "Unable to render text surface! SDL_ttf Error: %s\n", SDL_GetError() );
    }
    else
    {
        //Create texture from surface
        if( mTexture = SDL_CreateTextureFromSurface( gRenderer, textSurface ); mTexture == nullptr )
        {
            SDL_Log( "Unable to create texture from rendered text! SDL Error: %s\n", SDL_GetError() );
        }
        else
        {
            mWidth = textSurface->w;
            mHeight = textSurface->h;
        }

        //Free temp surface
        SDL_DestroySurface( textSurface );
    }
    
    //Return success if texture loaded
    return mTexture != nullptr;
}
#endif

void LTexture::destroy()
{
    //Clean up texture
    SDL_DestroyTexture( mTexture );
    mTexture = nullptr;
    mWidth = 0;
    mHeight = 0;
}

void LTexture::setColor( Uint8 r, Uint8 g, Uint8 b )
{
    SDL_SetTextureColorMod( mTexture, r, g, b );
}

void LTexture::setAlpha( Uint8 alpha )
{
    SDL_SetTextureAlphaMod( mTexture, alpha );
}

void LTexture::setBlending( SDL_BlendMode blendMode )
{
    SDL_SetTextureBlendMode( mTexture, blendMode );
}

void LTexture::render( float x, float y, SDL_FRect* clip, float width, float height, double degrees, SDL_FPoint* center, SDL_FlipMode flipMode )
{
    //Set texture position
    SDL_FRect dstRect{ x, y, static_cast<float>( mWidth ), static_cast<float>( mHeight ) };

    //Default to clip dimensions if clip is given
    if( clip != nullptr )
    {
        dstRect.w = clip->w;
        dstRect.h = clip->h;
    }

    //Resize if new dimensions are given
    if( width > 0 )
    {
        dstRect.w = width;
    }
    if( height > 0 )
    {
        dstRect.h = height;
    }

    //Render texture
    SDL_RenderTextureRotated( gRenderer, mTexture, clip, &dstRect, degrees, center, flipMode );
}

int LTexture::getWidth()
{
    return mWidth;
}

int LTexture::getHeight()
{
    return mHeight;
}

bool LTexture::isLoaded()
{
    return mTexture != nullptr;
}

//LTimer Implementation
LTimer::LTimer():
    mStartTicks{ 0 },
    mPausedTicks{ 0 },

    mPaused{ false },
    mStarted{ false }
{

}

void LTimer::start()
{
    //Start the timer
    mStarted = true;

    //Unpause the timer
    mPaused = false;

    //Get the current clock time
    mStartTicks = SDL_GetTicksNS();
    mPausedTicks = 0;
}

void LTimer::stop()
{
    //Stop the timer
    mStarted = false;

    //Unpause the timer
    mPaused = false;

    //Clear tick variables
    mStartTicks = 0;
    mPausedTicks = 0;
}

void LTimer::pause()
{
    //If the timer is running and isn't already paused
    if( mStarted && !mPaused )
    {
        //Pause the timer
        mPaused = true;

        //Calculate the paused ticks
        mPausedTicks = SDL_GetTicksNS() - mStartTicks;
        mStartTicks = 0;
    }
}

void LTimer::unpause()
{
    //If the timer is running and paused
    if( mStarted && mPaused )
    {
        //Unpause the timer
        mPaused = false;

        //Reset the starting ticks
        mStartTicks = SDL_GetTicksNS() - mPausedTicks;

        //Reset the paused ticks
        mPausedTicks = 0;
    }
}

Uint64 LTimer::getTicksNS()
{
    //The actual timer time
    Uint64 time{ 0 };

    //If the timer is running
    if( mStarted )
    {
        //If the timer is paused
        if( mPaused )
        {
            //Return the number of ticks when the timer was paused
            time = mPausedTicks;
        }
        else
        {
            //Return the current time minus the start time
            time = SDL_GetTicksNS() - mStartTicks;
        }
    }

    return time;
}

bool LTimer::isStarted()
{
    //Timer is running and paused or unpaused
    return mStarted;
}

bool LTimer::isPaused()
{
    //Timer is running and paused
    return mPaused && mStarted;
}

//Dot Implementation
Dot::Dot():
    mCollisionBox{ 0, 0, kDotWidth, kDotHeight },
    mVelX{ 0 },
    mVelY{ 0 }
{

}

void Dot::setPos( int x, int y )
{
    //Set position
    mCollisionBox.x = x;
    mCollisionBox.y = y;
}

void Dot::handleEvent( SDL_Event& e )
{
    //If a key was pressed
    if( e.type == SDL_EVENT_KEY_DOWN && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.key )
        {
            case SDLK_UP: mVelY -= kDotVel; break;
            case SDLK_DOWN: mVelY += kDotVel; break;
            case SDLK_LEFT: mVelX -= kDotVel; break;
            case SDLK_RIGHT: mVelX += kDotVel; break;
        }
    }
    //If a key was released
    else if( e.type == SDL_EVENT_KEY_UP && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.key )
        {
            case SDLK_UP: mVelY += kDotVel; break;
            case SDLK_DOWN: mVelY -= kDotVel; break;
            case SDLK_LEFT: mVelX += kDotVel; break;
            case SDLK_RIGHT: mVelX -= kDotVel; break;
        }
    }
}

void Dot::move( int levelWidth, int levelHeight )
{
    //Move the dot left or right
    mCollisionBox.x += mVelX;

    //If the dot went too far to the left or right
    if( ( mCollisionBox.x < 0 ) || ( mCollisionBox.x + kDotWidth > levelWidth ) )
    {
        //Move back
        mCollisionBox.x -= mVelX;
    }

    //Move the dot up or down
    mCollisionBox.y += mVelY;

    //If the dot went too far up or down
    if( ( mCollisionBox.y < 0 ) || ( mCollisionBox.y + kDotHeight > levelHeight ) )
    {
        //Move back
        mCollisionBox.y -= mVelY;
    }
}

void Dot::render( SDL_Rect camera )
{
    //Show the dot
    gDotTexture.render( static_cast<float>( mCollisionBox.x ) - camera.x, static_cast<float>( mCollisionBox.y ) - camera.y );
}

SDL_Rect Dot::getCollider()
{
    return mCollisionBox;
}

//House Implementation
House::House():
    mCollisionBox{ 0, 0, kHouseWidth, kHouseHeight },
    mHouseTexture{ nullptr }
{
}

void House::set( int x, int y, LTexture* houseTexture )
{
    //Initialize position
    mCollisionBox.x = x;
    mCollisionBox.y = y;

    //Initialize texture
    mHouseTexture = houseTexture;
}

void House::render( SDL_Rect camera )
{
    //Show the house relative to the camera
    mHouseTexture->render( static_cast<float>( mCollisionBox.x ) - camera.x, static_cast<float>( mCollisionBox.y ) - camera.y );
}

SDL_Rect House::getCollider()
{
    return mCollisionBox;
}

//Door Implementation
Door::Door():
    mCollisionBox{ 0, 0, kDoorWidth, kDoorHeight }
{
}

void Door::set( int x, int y )
{
    //Initialize position
    mCollisionBox.x = x;
    mCollisionBox.y = y;
}

void Door::render()
{
    //Draw rectangle for door
    SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0x00, 0xFF );
    SDL_FRect renderRect{ static_cast<float>( mCollisionBox.x ), static_cast<float>( mCollisionBox.y ), static_cast<float>( mCollisionBox.w ), static_cast<float>( mCollisionBox.h ) };
    SDL_RenderFillRect( gRenderer, &renderRect );
}

SDL_Rect Door::getCollider()
{
    return mCollisionBox;
}

//IntoState Implementation
IntroState* IntroState::get()
{
    //Get static instance
    return &sIntroState;
}

bool IntroState::enter()
{
    //Loading success flag
    bool success = true;

    //Load background
    if( mBackgroundTexture.loadFromFile( "19-state-machines/intro-bg.png" ) == false )
    {
        SDL_Log( "Failed to intro background!\n" );
        success = false;
    }

    //Load text
    SDL_Color textColor{ 0x00, 0x00, 0x00, 0xFF };
    if( mMessageTexture.loadFromRenderedText( "Lazy Foo' Productions Presents...", textColor ) == false )
    {
        SDL_Log( "Failed to render intro text!\n" );
        success = false;
    }

    return success;
}

bool IntroState::exit()
{
    //Free background and text
    mBackgroundTexture.destroy();
    mMessageTexture.destroy();

    return true;
}

void IntroState::handleEvent( SDL_Event& e )
{
    //If the user pressed enter
    if( ( e.type == SDL_EVENT_KEY_DOWN ) && ( e.key.key == SDLK_RETURN ) )
    {
        //Move onto title state
        setNextState( TitleState::get() );
    }
}

void IntroState::update()
{

}

void IntroState::render()
{
    //Show the background
    mBackgroundTexture.render( 0, 0 );

    //Show the message
    mMessageTexture.render( ( kScreenWidth - mMessageTexture.getWidth() ) / 2.f, ( kScreenHeight - mMessageTexture.getHeight() ) / 2.f );
}

//Declare static instance
IntroState IntroState::sIntroState;

IntroState::IntroState()
{
    //No public instantiation
}


//TitleState Implementation
TitleState* TitleState::get()
{
    //Get static instance
    return &sTitleState;
}

bool TitleState::enter()
{
    //Loading success flag
    bool success = true;

    //Load background
    if( mBackgroundTexture.loadFromFile( "19-state-machines/title-bg.png" ) == false )
    {
        SDL_Log( "Failed to title background!\n" );
        success = false;
    }

    //Load text
    SDL_Color textColor{ 0x00, 0x00, 0x00, 0xFF };
    if( mMessageTexture.loadFromRenderedText( "A State Machine Demo", textColor ) == false )
    {
        SDL_Log( "Failed to render title text!\n" );
        success = false;
    }

    return success;
}

bool TitleState::exit()
{
    //Free background and text
    mBackgroundTexture.destroy();
    mMessageTexture.destroy();

    return true;
}

void TitleState::handleEvent( SDL_Event& e )
{
    //If the user pressed enter
    if( ( e.type == SDL_EVENT_KEY_DOWN ) && ( e.key.key == SDLK_RETURN ) )
    {
        //Move to overworld
        setNextState( OverWorldState::get() );
    }
}

void TitleState::update()
{

}

void TitleState::render()
{
    //Show the background
    mBackgroundTexture.render( 0, 0 );

    //Show the message
    mMessageTexture.render( ( kScreenWidth - mMessageTexture.getWidth() ) / 2.f, ( kScreenHeight - mMessageTexture.getHeight() ) / 2.f );
}

//Declare static instance
TitleState TitleState::sTitleState;

TitleState::TitleState()
{
    //No public instantiation
}


//OverWorldState Implementation
OverWorldState* OverWorldState::get()
{
    //Get static instance
    return &sOverWorldState;
}

bool OverWorldState::enter()
{
    //Loading success flag
    bool success = true;

    //Load background
    if( mBackgroundTexture.loadFromFile( "19-state-machines/green-overworld.png" ) == false )
    {
        SDL_Log( "Failed to load overworld background!\n" );
        success = false;
    }

    //Load house texture
    if( mBlueHouseTexture.loadFromFile( "19-state-machines/blue-house.png" ) == false )
    {
        SDL_Log( "Failed to load blue house texture!\n" );
        success = false;
    }

    //Load house texture
    if( mRedHouseTexture.loadFromFile( "19-state-machines/red-house.png" ) == false )
    {
        SDL_Log( "Failed to load red house texture!\n" );
        success = false;
    }

    //Position houses with graphics
    mRedHouse.set( 0, 0, &mRedHouseTexture );
    mBlueHouse.set( kLevelWidth - House::kHouseWidth, kLevelHeight - House::kHouseHeight, &mBlueHouseTexture );

    //Came from red room state
    if( gCurrentState == RedRoomState::get() )
    {
        //Position below red house
        gDot.setPos( mRedHouse.getCollider().x + ( House::kHouseWidth - Dot::kDotWidth ) / 2, mRedHouse.getCollider().y + mRedHouse.getCollider().h + Dot::kDotHeight );
    }
    //Came from blue room state
    else if( gCurrentState == BlueRoomState::get() )
    {
        //Position above blue house
        gDot.setPos( mBlueHouse.getCollider().x + ( House::kHouseWidth - Dot::kDotWidth ) / 2, mBlueHouse.getCollider().y - Dot::kDotHeight * 2 );
    }
    //Came from other state
    else
    {
        //Position middle of overworld
        gDot.setPos( ( kLevelWidth - Dot::kDotWidth ) / 2, ( kLevelWidth - Dot::kDotHeight ) / 2 );
    }

    return success;
}

bool OverWorldState::exit()
{
    //Free textures
    mBackgroundTexture.destroy();
    mRedHouseTexture.destroy();
    mBlueHouseTexture.destroy();

    return true;
}

void OverWorldState::handleEvent( SDL_Event& e )
{
    //Handle dot input
    gDot.handleEvent( e );
}

void OverWorldState::update()
{
    //Move dot
    gDot.move( kLevelWidth, kLevelHeight );

    //On red house collision
    if( checkCollision( gDot.getCollider(), mRedHouse.getCollider() ) == true )
    {
        //Got to red room
        setNextState( RedRoomState::get() );
    }
    //On blue house collision
    else if( checkCollision( gDot.getCollider(), mBlueHouse.getCollider() ) == true )
    {
        //Go to blue room
        setNextState( BlueRoomState::get() );
    }
}

void OverWorldState::render()
{
    //Center the camera over the dot
    SDL_Rect camera{ ( gDot.getCollider().x + Dot::kDotWidth / 2 ) - kScreenWidth / 2, ( gDot.getCollider().y + Dot::kDotHeight / 2 ) - kScreenHeight / 2, kScreenWidth, kScreenHeight };

    //Keep the camera in bounds
    if( camera.x < 0 )
    { 
        camera.x = 0;
    }
    if( camera.y < 0 )
    {
        camera.y = 0;
    }
    if( camera.x > kLevelWidth - camera.w )
    {
        camera.x = kLevelWidth - camera.w;
    }
    if( camera.y > kLevelHeight - camera.h )
    {
        camera.y = kLevelHeight - camera.h;
    }

    //Render background
    SDL_FRect bgClip{ static_cast<float>( camera.x ), static_cast<float>( camera.y ), static_cast<float>( camera.w ), static_cast<float>( camera.h ) };
    mBackgroundTexture.render( 0, 0, &bgClip );

    //Render objects
    mRedHouse.render( camera );
    mBlueHouse.render( camera );
    gDot.render( camera );
}

//Declare static instance
OverWorldState OverWorldState::sOverWorldState;

OverWorldState::OverWorldState()
{
    //No public instantiation
}


//RedRoomState Implementation
RedRoomState* RedRoomState::get()
{
    //Get static instance
    return &sRedRoomState;
}

bool RedRoomState::enter()
{
    //Loading success flag
    bool success = true;

    //Load background
    if( mBackgroundTexture.loadFromFile( "19-state-machines/red-room.png" ) == false )
    {
        SDL_Log( "Failed to load blue room background!\n" );
        success = false;
    }

    //Place game objects
    mExitDoor.set( ( kLevelWidth - Door::kDoorWidth ) / 2, kLevelHeight - Door::kDoorHeight );
    gDot.setPos( ( kLevelWidth - Dot::kDotWidth ) / 2, kLevelHeight - Door::kDoorHeight - Dot::kDotHeight * 2 );

    return success;
}

bool RedRoomState::exit()
{
    //Free background
    mBackgroundTexture.destroy();

    return true;
}

void RedRoomState::handleEvent( SDL_Event& e )
{
    //Handle dot input
    gDot.handleEvent( e );
}

void RedRoomState::update()
{
    //Move dot
    gDot.move( kLevelWidth, kLevelHeight );

    //On exit collision
    if( checkCollision( gDot.getCollider(), mExitDoor.getCollider() ) == true )
    {
        //Go back to overworld
        setNextState( OverWorldState::get() );
    }
}

void RedRoomState::render()
{
    //Center the camera over the dot
    SDL_Rect camera{ 0, 0, kScreenWidth, kScreenHeight };

    //Render background
    mBackgroundTexture.render( 0, 0 );

    //Render objects
    mExitDoor.render();
    gDot.render( camera );
}

//Declare static instance
RedRoomState RedRoomState::sRedRoomState;

RedRoomState::RedRoomState()
{
    //No public instantiation
}


//BlueRoomState Implementation
BlueRoomState* BlueRoomState::get()
{
    //Get static instance
    return &sBlueRoomState;
}

bool BlueRoomState::enter()
{
    //Loading success flag
    bool success = true;

    //Load background
    if( mBackgroundTexture.loadFromFile( "19-state-machines/blue-room.png" ) == false )
    {
        SDL_Log( "Failed to load blue room background!\n" );
        success = false;
    }

    //Position game objects
    mExitDoor.set( ( kLevelWidth - Door::kDoorWidth ) / 2, 0 );
    gDot.setPos( ( kLevelWidth - Dot::kDotWidth ) / 2, Door::kDoorHeight + Dot::kDotHeight * 2 );

    return success;
}

bool BlueRoomState::exit()
{
    //Free background
    mBackgroundTexture.destroy();

    return true;
}

void BlueRoomState::handleEvent( SDL_Event& e )
{
    //Handle dot input
    gDot.handleEvent( e );
}

void BlueRoomState::update()
{
    //Move dot
    gDot.move( kLevelWidth, kLevelHeight );

    //On exit collision
    if( checkCollision( gDot.getCollider(), mExitDoor.getCollider() ) == true )
    {
        //Back to overworld
        setNextState( OverWorldState::get() );
    }
}

void BlueRoomState::render()
{
    //Center the camera over the dot
    SDL_Rect camera{ 0, 0, kScreenWidth, kScreenHeight };

    //Render background
    mBackgroundTexture.render( 0, 0 );

    //Render objects
    mExitDoor.render();
    gDot.render( camera );
}

//Declare static instance
BlueRoomState BlueRoomState::sBlueRoomState;

BlueRoomState::BlueRoomState()
{
    //No public instantiation
}


//Hollow exit state
ExitState* ExitState::get()
{
    return &sExitState;
}

bool ExitState::enter()
{
    return true;
}
    
bool ExitState::exit()
{
    return true;
}

void ExitState::handleEvent( SDL_Event& e )
{

}

void ExitState::update()
{

}

void ExitState::render()
{

}

ExitState ExitState::sExitState;

ExitState::ExitState()
{

}


/* Function Implementations */
bool init()
{
    //Initialization flag
    bool success{ true };

    //Initialize SDL
    if( SDL_Init( SDL_INIT_VIDEO ) == false )
    {
        SDL_Log( "SDL could not initialize! SDL error: %s\n", SDL_GetError() );
        success = false;
    }
    else
    {
        //Create window with renderer
        if( SDL_CreateWindowAndRenderer( "SDL3 Tutorial: State Machines", kScreenWidth, kScreenHeight, 0, &gWindow, &gRenderer ) == false )
        {
            SDL_Log( "Window could not be created! SDL error: %s\n", SDL_GetError() );
            success = false;
        }
        else
        {
            //Initialize font loading
            if( TTF_Init() == false )
            {
                SDL_Log( "SDL_ttf could not initialize! SDL_ttf error: %s\n", SDL_GetError() );
                success = false;
            }
        }
    }

    return success;
}

bool loadMedia()
{
    //File loading flag
    bool success{ true };

    //Load glocal assets
    if( gDotTexture.loadFromFile( "19-state-machines/dot.png" ) == false )
    {
        SDL_Log( "Unable to dot image!\n");
        success = false;
    }
    //Load scene font
    std::string fontPath{ "19-state-machines/lazy.ttf" };
    if( gFont = TTF_OpenFont( fontPath.c_str(), 28 ); gFont == nullptr )
    {
        SDL_Log( "Could not load %s! SDL_ttf Error: %s\n", fontPath.c_str(), SDL_GetError() );
        success = false;
    }

    return success;
}

void close()
{
    //Clean up textures
    gDotTexture.destroy();

    //Free font
    TTF_CloseFont( gFont );
    gFont = nullptr;

    //Destroy window
    SDL_DestroyRenderer( gRenderer );
    gRenderer = nullptr;
    SDL_DestroyWindow( gWindow );
    gWindow = nullptr;

    //Quit SDL subsystems
    TTF_Quit();
    SDL_Quit();
}

void setNextState( GameState* newState )
{
    //If the user doesn't want to exit
    if( gNextState != ExitState::get() )
    {
        //Set the next state
        gNextState = newState;
    }
}

bool changeState()
{
    //Flag successful state changes
    bool success{ true };

    //If the state needs to be changed
    if( gNextState != nullptr )
    {
        success = gCurrentState->exit() && success;
        success = gNextState->enter() && success;

        //Change the current state ID
        gCurrentState = gNextState;
        gNextState = nullptr;
    }

    return success;
}

bool checkCollision( SDL_Rect a, SDL_Rect b )
{
    //Calculate the sides of rect A
    int aMinX{ a.x };
    int aMaxX{ a.x + a.w };
    int aMinY{ a.y };
    int aMaxY{ a.y + a.h };

    //Calculate the sides of rect B
    int bMinX{ b.x };
    int bMaxX{ b.x + b.w };
    int bMinY{ b.y };
    int bMaxY{ b.y + b.h };

    //If left side of A is the the right of B
    if( aMinX >= bMaxX )
    {
        return false;
    }

    //If the right side of A to the left of B
    if( aMaxX <= bMinX )
    {
        return false;
    }

    //If the top side of A is below B
    if( aMinY >= bMaxY )
    {
        return false;
    }

    //If the bottom side of A is above B
    if( aMaxY <= bMinY )
    {
        return false;
    }

    //If none of the sides from A are outside B
    return true;
}


int main( int argc, char* args[] )
{
    //Final exit code
    int exitCode{ 0 };

    //Initialize
    if( init() == false )
    {
        SDL_Log( "Unable to initialize program!\n" );
        exitCode = 1;
    }
    else
    {
        //Load media
        if( loadMedia() == false )
        {
            SDL_Log( "Unable to load media!\n" );
            exitCode = 2;
        }
        else
        {
            //The event data
            SDL_Event e;
            SDL_zero( e );

            //Timer to cap frame rate
            LTimer capTimer;

            //Set the current game state object and start state machine
            gCurrentState = IntroState::get();
            if( gCurrentState->enter() == false )
            {
                gCurrentState->exit();
                gCurrentState = ExitState::get();
            }

            //The main loop
            while( gCurrentState != ExitState::get() )
            {
                //Start frame time
                capTimer.start();

                //Get event data
                while( SDL_PollEvent( &e ) == true )
                {
                    //Handle state events
                    gCurrentState->handleEvent( e );

                    //Exit on quit
                    if( e.type == SDL_EVENT_QUIT )
                    {
                        setNextState( ExitState::get() );
                    }
                }
                
                //Do state logic
                gCurrentState->update();

                //Change state if needed
                if( changeState() == false )
                {
                    //Exit on state change failure
                    gCurrentState->exit();
                    gCurrentState = ExitState::get();
                }

                //Fill the background
                SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF,  0xFF );
                SDL_RenderClear( gRenderer );

                //Do state rendering
                gCurrentState->render();

                //Update screen
                SDL_RenderPresent( gRenderer );

                //Cap frame rate
                constexpr Uint64 nsPerFrame = 1000000000 / kScreenFps; 
                Uint64 frameNs{ capTimer.getTicksNS() };
                if( frameNs < nsPerFrame )
                {
                    SDL_DelayNS( nsPerFrame - frameNs );
                }
            } 
        }
    }

    //Clean up
    close();

    return exitCode;
}
