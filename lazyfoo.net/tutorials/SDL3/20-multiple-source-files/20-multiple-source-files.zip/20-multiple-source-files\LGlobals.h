/*This source code copyrighted by Lazy Foo' Productions 2004-2026
and may not be redistributed without written permission.*/

#ifndef LGLOBALS_H
#define LGLOBALS_H

#include <SDL3/SDL.h>
#include "LTexture.h"

//The window we'll be rendering to
extern SDL_Window* gWindow;

//The renderer used to draw to the window
extern SDL_Renderer* gRenderer;

//Dot texture
extern LTexture gDotTexture;

#endif
