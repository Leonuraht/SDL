/*This source code copyrighted by Lazy Foo' Productions 2004-2026
and may not be redistributed without written permission.*/

#include "LGlobals.h"

//Instatiate globals
SDL_Window* gWindow{ nullptr };
SDL_Renderer* gRenderer{ nullptr };
LTexture gDotTexture;
