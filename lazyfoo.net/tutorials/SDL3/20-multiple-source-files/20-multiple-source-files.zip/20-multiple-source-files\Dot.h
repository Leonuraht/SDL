/*This source code copyrighted by Lazy Foo' Productions 2004-2026
and may not be redistributed without written permission.*/

#ifndef DOT_H
#define DOT_H

#include <SDL3/SDL.h>

class Dot
{
public:
    //The dimensions of the dot
    static constexpr int kDotWidth = 20;
    static constexpr int kDotHeight = 20;

    //Maximum axis velocity of the dot
    static constexpr int kDotVel = 10;

    //Initializes the variables
    Dot();

    //Takes key presses and adjusts the dot's velocity
    void handleEvent( SDL_Event& e );

    //Moves the dot
    void move();

    //Shows the dot on the screen
    void render();

private:
    //The X and Y offsets of the dot
    int mPosX, mPosY;

    //The velocity of the dot
    int mVelX, mVelY;
};

#endif
