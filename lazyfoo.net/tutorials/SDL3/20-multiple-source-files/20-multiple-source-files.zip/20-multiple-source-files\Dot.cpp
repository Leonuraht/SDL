/*This source code copyrighted by Lazy Foo' Productions 2004-2026
and may not be redistributed without written permission.*/

#include "Dot.h"
#include "LConst.h"
#include "LGlobals.h"

Dot::Dot() :
    mPosX{ 0 },
    mPosY{ 0 },
    mVelX{ 0 },
    mVelY{ 0 }
{

}

void Dot::handleEvent( SDL_Event& e )
{
    //If a key was pressed
    if( e.type == SDL_EVENT_KEY_DOWN && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch(e.key.key)
        {
        case SDLK_UP: mVelY -= kDotVel; break;
        case SDLK_DOWN: mVelY += kDotVel; break;
        case SDLK_LEFT: mVelX -= kDotVel; break;
        case SDLK_RIGHT: mVelX += kDotVel; break;
        }
    }
    //If a key was released
    else if( e.type == SDL_EVENT_KEY_UP && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch(e.key.key)
        {
        case SDLK_UP: mVelY += kDotVel; break;
        case SDLK_DOWN: mVelY -= kDotVel; break;
        case SDLK_LEFT: mVelX += kDotVel; break;
        case SDLK_RIGHT: mVelX -= kDotVel; break;
        }
    }
}

void Dot::move()
{
    //Move the dot left or right
    mPosX += mVelX;

    //If the dot went too far to the left or right
    if( ( mPosX < 0 ) || ( mPosX + kDotWidth > kScreenWidth ) )
    {
        //Move back
        mPosX -= mVelX;
    }

    //Move the dot up or down
    mPosY += mVelY;

    //If the dot went too far up or down
    if( ( mPosY < 0 ) || ( mPosY + kDotHeight > kScreenHeight ) )
    {
        //Move back
        mPosY -= mVelY;
    }
}

void Dot::render()
{
    //Show the dot
    gDotTexture.render( static_cast<float>(mPosX), static_cast<float>(mPosY) );
}
