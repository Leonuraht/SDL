/*This source code copyrighted by Lazy Foo' Productions 2004-2026
and may not be redistributed without written permission.*/

/* Headers */
//Using SDL, SDL_image, SDL_mixer, and STL string
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_image/SDL_image.h>
#include <SDL3_mixer/SDL_mixer.h>
#include <string>


/* Constants */
//Screen dimension constants
constexpr int kScreenWidth{ 640 };
constexpr int kScreenHeight{ 480 };
constexpr int kScreenFps{ 60 };


/* Class Prototypes */
class LTexture
{
public:
    //Symbolic constant
    static constexpr float kOriginalSize = -1.f;

    //Initializes texture variables
    LTexture();

    //Cleans up texture variables
    ~LTexture();

    //Loads texture from disk
    bool loadFromFile( std::string path );

    #if defined(SDL_TTF_MAJOR_VERSION)
    //Creates texture from text
    bool loadFromRenderedText( std::string textureText, SDL_Color textColor );
    #endif

    //Cleans up texture
    void destroy();

    //Sets color modulation
    void setColor( Uint8 r, Uint8 g, Uint8 b);

    //Sets opacity
    void setAlpha( Uint8 alpha );

    //Sets blend mode
    void setBlending( SDL_BlendMode blendMode );

    //Draws texture
    void render( float x, float y, SDL_FRect* clip = nullptr, float width = kOriginalSize, float height = kOriginalSize, double degrees = 0.0, SDL_FPoint* center = nullptr, SDL_FlipMode flipMode = SDL_FLIP_NONE );

    //Gets texture attributes
    int getWidth();
    int getHeight();
    bool isLoaded();

private:
    //Contains texture data
    SDL_Texture* mTexture;

    //Texture dimensions
    int mWidth;
    int mHeight;
};

class LTimer
{
    public:
        //Initializes variables
        LTimer();

        //The various clock actions
        void start();
        void stop();
        void pause();
        void unpause();

        //Gets the timer's time
        Uint64 getTicksNS();

        //Checks the status of the timer
        bool isStarted();
        bool isPaused();

    private:
        //The clock time when the timer started
        Uint64 mStartTicks;

        //The ticks stored when the timer was paused
        Uint64 mPausedTicks;

        //The timer status
        bool mPaused;
        bool mStarted;
};


/* Function Prototypes */
//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();


/* Global Variables */
//The window we'll be rendering to
SDL_Window* gWindow{ nullptr };

//The renderer used to draw to the window
SDL_Renderer* gRenderer{ nullptr };

//Instruction texture
LTexture gPromptTexture;

//The mixer to output to
MIX_Mixer* gMixer{ nullptr };

//The track containing music that will be played
MIX_Track* gMusicTrack{ nullptr };

//The sound effects that will be used
MIX_Audio* gScratchAudio{ nullptr };
MIX_Audio* gHighAudio{ nullptr };
MIX_Audio* gMediumAudio{ nullptr };
MIX_Audio* gLowAudio{ nullptr };

//The track the sound effects will be played on
MIX_Track* gEffectTrack{ nullptr };


/* Class Implementations */
//LTexture Implementation
LTexture::LTexture():
    //Initialize texture variables
    mTexture{ nullptr },
    mWidth{ 0 },
    mHeight{ 0 }
{

}

LTexture::~LTexture()
{
    //Clean up texture
    destroy();
}

bool LTexture::loadFromFile( std::string path )
{
    //Clean up texture if it already exists
    destroy();

    //Load surface
    if( SDL_Surface* loadedSurface = IMG_Load( path.c_str() ); loadedSurface == nullptr )
    {
        SDL_Log( "Unable to load image %s! SDL_image error: %s\n", path.c_str(), SDL_GetError() );
    }
    else
    {
        //Color key image
        if( SDL_SetSurfaceColorKey( loadedSurface, true, SDL_MapSurfaceRGB( loadedSurface, 0x00, 0xFF, 0xFF ) ) == false )
        {
            SDL_Log( "Unable to color key! SDL error: %s", SDL_GetError() );
        }
        else
        {
            //Create texture from surface
            if( mTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface ); mTexture == nullptr )
            {
                SDL_Log( "Unable to create texture from loaded pixels! SDL error: %s\n", SDL_GetError() );
            }
            else
            {
                //Get image dimensions
                mWidth = loadedSurface->w;
                mHeight = loadedSurface->h;
            }
        }
        
        //Clean up loaded surface
        SDL_DestroySurface( loadedSurface );
    }

    //Return success if texture loaded
    return mTexture != nullptr;
}

#if defined(SDL_TTF_MAJOR_VERSION)
bool LTexture::loadFromRenderedText( std::string textureText, SDL_Color textColor )
{
    //Clean up existing texture
    destroy();

    //Load text surface
    if( SDL_Surface* textSurface = TTF_RenderText_Blended( gFont, textureText.c_str(), 0, textColor ); textSurface == nullptr )
    {
        SDL_Log( "Unable to render text surface! SDL_ttf Error: %s\n", SDL_GetError() );
    }
    else
    {
        //Create texture from surface
        if( mTexture = SDL_CreateTextureFromSurface( gRenderer, textSurface ); mTexture == nullptr )
        {
            SDL_Log( "Unable to create texture from rendered text! SDL Error: %s\n", SDL_GetError() );
        }
        else
        {
            mWidth = textSurface->w;
            mHeight = textSurface->h;
        }

        //Free temp surface
        SDL_DestroySurface( textSurface );
    }
    
    //Return success if texture loaded
    return mTexture != nullptr;
}
#endif

void LTexture::destroy()
{
    //Clean up texture
    SDL_DestroyTexture( mTexture );
    mTexture = nullptr;
    mWidth = 0;
    mHeight = 0;
}

void LTexture::setColor( Uint8 r, Uint8 g, Uint8 b )
{
    SDL_SetTextureColorMod( mTexture, r, g, b );
}

void LTexture::setAlpha( Uint8 alpha )
{
    SDL_SetTextureAlphaMod( mTexture, alpha );
}

void LTexture::setBlending( SDL_BlendMode blendMode )
{
    SDL_SetTextureBlendMode( mTexture, blendMode );
}

void LTexture::render( float x, float y, SDL_FRect* clip, float width, float height, double degrees, SDL_FPoint* center, SDL_FlipMode flipMode )
{
    //Set texture position
    SDL_FRect dstRect{ x, y, static_cast<float>( mWidth ), static_cast<float>( mHeight ) };

    //Default to clip dimensions if clip is given
    if( clip != nullptr )
    {
        dstRect.w = clip->w;
        dstRect.h = clip->h;
    }

    //Resize if new dimensions are given
    if( width > 0 )
    {
        dstRect.w = width;
    }
    if( height > 0 )
    {
        dstRect.h = height;
    }

    //Render texture
    SDL_RenderTextureRotated( gRenderer, mTexture, clip, &dstRect, degrees, center, flipMode );
}

int LTexture::getWidth()
{
    return mWidth;
}

int LTexture::getHeight()
{
    return mHeight;
}

bool LTexture::isLoaded()
{
    return mTexture != nullptr;
}

//LTimer Implementation
LTimer::LTimer():
    mStartTicks{ 0 },
    mPausedTicks{ 0 },

    mPaused{ false },
    mStarted{ false }
{

}

void LTimer::start()
{
    //Start the timer
    mStarted = true;

    //Unpause the timer
    mPaused = false;

    //Get the current clock time
    mStartTicks = SDL_GetTicksNS();
    mPausedTicks = 0;
}

void LTimer::stop()
{
    //Stop the timer
    mStarted = false;

    //Unpause the timer
    mPaused = false;

    //Clear tick variables
    mStartTicks = 0;
    mPausedTicks = 0;
}

void LTimer::pause()
{
    //If the timer is running and isn't already paused
    if( mStarted && !mPaused )
    {
        //Pause the timer
        mPaused = true;

        //Calculate the paused ticks
        mPausedTicks = SDL_GetTicksNS() - mStartTicks;
        mStartTicks = 0;
    }
}

void LTimer::unpause()
{
    //If the timer is running and paused
    if( mStarted && mPaused )
    {
        //Unpause the timer
        mPaused = false;

        //Reset the starting ticks
        mStartTicks = SDL_GetTicksNS() - mPausedTicks;

        //Reset the paused ticks
        mPausedTicks = 0;
    }
}

Uint64 LTimer::getTicksNS()
{
    //The actual timer time
    Uint64 time{ 0 };

    //If the timer is running
    if( mStarted )
    {
        //If the timer is paused
        if( mPaused )
        {
            //Return the number of ticks when the timer was paused
            time = mPausedTicks;
        }
        else
        {
            //Return the current time minus the start time
            time = SDL_GetTicksNS() - mStartTicks;
        }
    }

    return time;
}

bool LTimer::isStarted()
{
    //Timer is running and paused or unpaused
    return mStarted;
}

bool LTimer::isPaused()
{
    //Timer is running and paused
    return mPaused && mStarted;
}


/* Function Implementations */
bool init()
{
    //Initialization flag
    bool success{ true };

    //Initialize SDL with audio
    if( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO ) == false )
    {
        SDL_Log( "SDL could not initialize! SDL error: %s\n", SDL_GetError() );
        success = false;
    }
    else
    {
        //Create window with renderer
        if( SDL_CreateWindowAndRenderer( "SDL3 Tutorial: Sound Effects and Music", kScreenWidth, kScreenHeight, 0, &gWindow, &gRenderer ) == false )
        {
            SDL_Log( "Window could not be created! SDL error: %s\n", SDL_GetError() );
            success = false;
        }
        else
        {
            //Initialize SDL_mixer
            if( MIX_Init() == false )
            {
                SDL_Log( "SDL_mixer could not initialize! SDL_mixer Error: %s\n", SDL_GetError() );
                success = false;
            }
            else
            {
                //Create mixer 
                if( gMixer = MIX_CreateMixerDevice( SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, nullptr ); gMixer == nullptr )
                {
                    SDL_Log( "SDL_mixer could not create mixer! SDL_mixer Error: %s\n", SDL_GetError() );
                    success = false;
                }
            }
        }
    }

    return success;
}

bool loadMedia()
{
    //File loading flag
    bool success{ true };

    //Load scene image
    if( gPromptTexture.loadFromFile( "15-sound-effects-and-music/prompt.png" ) == false )
    {
        SDL_Log( "Unable to load prompt image!\n" );
        success = false;
    }

    //Load sound effects
    if( gScratchAudio = MIX_LoadAudio( gMixer, "15-sound-effects-and-music/scratch.wav", true ); gScratchAudio == nullptr )
    {
        SDL_Log( "Unable to load scratch sound! SDL_mixer error: %s\n", SDL_GetError() );
        success = false;
    }
    if( gHighAudio = MIX_LoadAudio( gMixer, "15-sound-effects-and-music/high.wav", true ); gHighAudio == nullptr )
    {
        SDL_Log( "Unable to load high sound! SDL_mixer error: %s\n", SDL_GetError() );
        success = false;
    }
    if( gMediumAudio = MIX_LoadAudio( gMixer, "15-sound-effects-and-music/medium.wav", true ); gMediumAudio == nullptr )
    {
        SDL_Log( "Unable to load medium sound! SDL_mixer error: %s\n", SDL_GetError() );
        success = false;
    }
    if( gLowAudio = MIX_LoadAudio( gMixer, "15-sound-effects-and-music/low.wav", true ); gLowAudio == nullptr )
    {
        SDL_Log( "Unable to load low sound! SDL_mixer error: %s\n", SDL_GetError() );
        success = false;
    }

    //Create track for sound effects
    if( gHighAudio != nullptr && gMediumAudio != nullptr && gLowAudio != nullptr )
    {
        if( gEffectTrack = MIX_CreateTrack( gMixer ); gEffectTrack == nullptr )
        {
            SDL_Log( "Failed to create sound effect track! SDL_mixer Error: %s\n", SDL_GetError() );
            success = false;
        }
    }

    //Load music audio
    if( MIX_Audio* musicAudio = MIX_LoadAudio( gMixer, "15-sound-effects-and-music/beat.wav", false ); musicAudio == nullptr )
    {
        SDL_Log( "Unable to load music! SDL_mixer error: %s\n", SDL_GetError() );
        success = false;
    }
    else
    {
        //Create track for music
        if( gMusicTrack = MIX_CreateTrack( gMixer ); gMusicTrack == nullptr )
        {
            SDL_Log( "Failed to create music track! SDL_mixer Error: %s\n", SDL_GetError() );
            success = false;
        }
        else
        {
            //Set audio for track
            MIX_SetTrackAudio( gMusicTrack, musicAudio );
        }

        //The track will hold a reference count
        MIX_DestroyAudio( musicAudio );
    }

    return success;
}

void close()
{
    //Free music track
    MIX_DestroyTrack( gMusicTrack );
    gMusicTrack = nullptr;

    //Sound effect track
    MIX_DestroyTrack( gEffectTrack );
    gEffectTrack = nullptr;

    //Free sound effects
    MIX_DestroyAudio( gScratchAudio );
    gScratchAudio = nullptr;
    MIX_DestroyAudio( gHighAudio );
    gHighAudio = nullptr;
    MIX_DestroyAudio( gMediumAudio );
    gMediumAudio = nullptr;
    MIX_DestroyAudio( gLowAudio );
    gLowAudio = nullptr;

    //Free the mixer
    MIX_DestroyMixer( gMixer );
    gMixer = nullptr;

    //Clean up textures
    gPromptTexture.destroy();

    //Destroy window
    SDL_DestroyRenderer( gRenderer );
    gRenderer = nullptr;
    SDL_DestroyWindow( gWindow );
    gWindow = nullptr;

    //Quit SDL subsystems
    MIX_Quit();
    SDL_Quit();
}


int main( int argc, char* args[] )
{
    //Final exit code
    int exitCode{ 0 };

    //Initialize
    if( init() == false )
    {
        SDL_Log( "Unable to initialize program!\n" );
        exitCode = 1;
    }
    else
    {
        //Load media
        if( loadMedia() == false )
        {
            SDL_Log( "Unable to load media!\n" );
            exitCode = 2;
        }
        else
        {
            //The quit flag
            bool quit{ false };

            //The event data
            SDL_Event e;
            SDL_zero( e );

            //Timer to cap frame rate
            LTimer capTimer;

            //The main loop
            while( quit == false )
            {
                //Start frame time
                capTimer.start();

                //Get event data
                while( SDL_PollEvent( &e ) == true )
                {
                    //If event is quit type
                    if( e.type == SDL_EVENT_QUIT )
                    {
                        //End the main loop
                        quit = true;
                    }
                    //Handle key press
                    else if( e.type == SDL_EVENT_KEY_DOWN )
                    {
                        switch( e.key.key )
                        {
                            //Play high sound effect
                            case SDLK_1:
                            MIX_SetTrackAudio( gEffectTrack, gHighAudio );
                            MIX_PlayTrack( gEffectTrack, 0 );
                            break;
                            
                            //Play medium sound effect
                            case SDLK_2:
                            MIX_SetTrackAudio( gEffectTrack, gMediumAudio );
                            MIX_PlayTrack( gEffectTrack, 0 );
                            break;
                            
                            //Play low sound effect
                            case SDLK_3:
                            MIX_SetTrackAudio( gEffectTrack, gLowAudio );
                            MIX_PlayTrack( gEffectTrack, 0 );
                            break;
                            
                            //Play scratch sound effect with track
                            case SDLK_4:
                            MIX_SetTrackAudio( gEffectTrack, gScratchAudio );
                            MIX_PlayTrack( gEffectTrack, 0 );
                            break;
                            
                            case SDLK_9:
                            //If there is no music playing
                            if( MIX_TrackPlaying( gMusicTrack ) == false && MIX_TrackPaused( gMusicTrack ) == false )
                            {
                                //Play the music
                                SDL_PropertiesID props = SDL_CreateProperties();
                                SDL_SetNumberProperty( props, MIX_PROP_PLAY_LOOPS_NUMBER, -1 );
                                MIX_PlayTrack( gMusicTrack, props );
                                SDL_DestroyProperties( props );
                            }
                            //If music is being played
                            else
                            {
                                //If the music is paused
                                if( MIX_TrackPaused( gMusicTrack ) == true )
                                {
                                    //Resume the music
                                    MIX_ResumeTrack( gMusicTrack );
                                }
                                //If the music is playing
                                else
                                {
                                    //Pause the music
                                    MIX_PauseTrack( gMusicTrack );
                                }
                            }
                            break;
                            
                            //Stop the music
                            case SDLK_0:
                            MIX_StopTrack( gMusicTrack, 0 );
                            break;
                        }
                    }
                }



                //Fill the background
                SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF,  0xFF );
                SDL_RenderClear( gRenderer );

                //Render instructions
                gPromptTexture.render( 0.f, 0.f );

                //Update screen
                SDL_RenderPresent( gRenderer );

                //Cap frame rate
                constexpr Uint64 nsPerFrame = 1000000000 / kScreenFps; 
                Uint64 frameNs{ capTimer.getTicksNS() };
                if( frameNs < nsPerFrame )
                {
                    SDL_DelayNS( nsPerFrame - frameNs );
                }
            } 
        }
    }

    //Clean up
    close();

    return exitCode;
}
