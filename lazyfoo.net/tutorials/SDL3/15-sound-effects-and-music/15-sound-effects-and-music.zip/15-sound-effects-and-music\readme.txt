Copyright Notice:
-----------------
The files within this zip file are copyrighted by Lazy Foo' Productions 2004-2026
and may not be redistributed without written permission.

This project is linked against:
----------------------------------------
Windows:
SDL3
SDL3_image
SDL3_mixer

*nix:
SDL3
SDL3_image
SDL3_mixer
